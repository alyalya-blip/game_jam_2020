"""
Filename: main.py
Author: D.C
Purpose: Main file for the *insert game name* game.
"""

from time import sleep
import os
import random
import pygame
import pygame_functions
import players

TYPES_ENUM = {'rock': 0, 'paper': 1, 'scissors': 2}

SCREEN_SIZE_X = 1280
SCREEN_SIZE_Y = 720

MAX_LUCK = 100
# TODO: increase the growth factor? At the moment it's difficult to tell that it's rising
LUCK_GROWTH_FACTOR = 1
LUCK_BAR_HEIGHT = 500
LUCK_TO_PIXELS_RATIO = LUCK_BAR_HEIGHT // MAX_LUCK

RESULT_DISPLAY_TIME = 3

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 50, 50)
YELLOW = (255, 255, 0)
GREEN = (0, 255, 50)
BLUE = (50, 50, 255)
GREY = (200, 200, 200)
ORANGE = (200, 100, 50)
CYAN = (0, 255, 255)
MAGENTA = (255, 0, 255)
TRANS = (1, 1, 1)


# center the window of the game on the screen (otherwise on my screen it doesn't work -Alona)
os.environ['SDL_VIDEO_CENTERED'] = '1'

class Card:
    def __init__(self, card_sprite, card_type, card_factor):
        """
        Initiate a card object.
        :param card_sprite: The path to the image file of the card. (str)
        :param card_type: The type of the card, rock, paper, scissors. (str)
        :param card_factor: The "level" of the card, between 1 and 20. (int)
        """

        self.card_sprite = card_sprite
        self.card_type = card_type
        self.card_factor = card_factor


def init_cards():
    """
    Initiate all the card objects.
    :return: A tuple containing all the cards in the enum order.
    """

    rock_types = {1: 'rock.png', 2: 'rock.png', 3: 'rock.png', 4: 'rock.png', 5: 'rock.png', 6: 'the_rock.png'}
    paper_types = {1: 'rock.png', 2: 'rock.png', 3: 'rock.png', 4: 'rock.png', 5: 'rock.png', 6: 'toilet_paper.png'}
    scissors_types = {1: 'rock.png', 2: 'rock.png', 3: 'chainsaw.png', 4: 'rock.png', 5: 'rock.png', 6: 'chainsaw.png'}

    #Initiate the card objects according to the given lists.
    rock_cards = [Card(pygame_functions.newSprite('assets\\pictures\\cards\\' + rock_types[key])\
                        , 'rock', key) for key in rock_types]
    paper_cards = [Card(pygame_functions.newSprite('assets\\pictures\\cards\\' + paper_types[key]) \
                         , 'paper', key) for key in paper_types]
    scissors_cards = [Card(pygame_functions.newSprite('assets\\pictures\\cards\\' + scissors_types[key]) \
                           , 'scissors', key) for key in scissors_types]

    return rock_cards, paper_cards, scissors_cards


def show_cards(current_luck, cards):
    """
    Show the option cards according to the dice roll.
    :param current_luck: The current roll outcome. (int)
    :param cards: The tuple containing the card objects. (tuple)

    :return: a tuple containing the sprites of the option cards.
    """

    OPTION_CARD_Y = SCREEN_SIZE_Y - 100
    OPTION_CARD_MIDDLE_X = SCREEN_SIZE_X // 2
    OPTIONS_CARD_SPACING = SCREEN_SIZE_X // 3

    rock_card = cards[TYPES_ENUM['rock']][current_luck - 1]
    paper_card = cards[TYPES_ENUM['paper']][current_luck - 1]
    scissors_card = cards[TYPES_ENUM['scissors']][current_luck - 1]

    pygame_functions.moveSprite(rock_card.card_sprite, OPTION_CARD_MIDDLE_X - OPTIONS_CARD_SPACING, OPTION_CARD_Y)
    pygame_functions.moveSprite(paper_card.card_sprite, OPTION_CARD_MIDDLE_X, OPTION_CARD_Y)
    pygame_functions.moveSprite(scissors_card.card_sprite, OPTION_CARD_MIDDLE_X + OPTIONS_CARD_SPACING, OPTION_CARD_Y)

    pygame_functions.showSprite(rock_card.card_sprite)
    pygame_functions.showSprite(paper_card.card_sprite)
    pygame_functions.showSprite(scissors_card.card_sprite)

    return rock_card, paper_card, scissors_card

def show_luck_meter(player):
    """
    Shows the luck meter of the current player. The meter is 50 by 500 pixels.
    :param player: the player whose luck meter we are showing
    :return: the sprite luck_meter
    """
    
    luck_x = 100
    luck_y = SCREEN_SIZE_Y // 1.5
    bar_x = luck_x
    # when the bar is at the meter's y coordinates plus half the meter's size, it's at
    # the bottom of the meter. The bar shows the amount of luck the player currently has, and
    # since the luck meter is 0 - 100 and the picture has 500 pixels, we substract luck * 5.
    bar_y = luck_y + (LUCK_BAR_HEIGHT // 2) - (player.get_luck() * LUCK_TO_PIXELS_RATIO)
    
    luck_meter = pygame_functions.newSprite('assets/pictures/luck/luck_meter.png')
    luck_bar = pygame_functions.newSprite('assets/pictures/luck/meter_bar.png')
    
    pygame_functions.moveSprite(luck_meter, luck_x, luck_y)
    pygame_functions.moveSprite(luck_bar, bar_x, bar_y)
    
    pygame_functions.showSprite(luck_meter)
    pygame_functions.showSprite(luck_bar)
    
    return luck_meter

def detect_choice(option_cards):
    """
    Detect which card was clicked and make the choice.
    :param option_cards: The options for the player to choose from. (tuple)
    :return: the type of the card and its factor
    """
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            elif pygame_functions.keyPressed('esc'):
                pygame.quit()
            else:
                if pygame_functions.spriteClicked(option_cards[TYPES_ENUM['rock']].card_sprite):
                    return make_choice(option_cards[TYPES_ENUM['rock']])

                elif pygame_functions.spriteClicked(option_cards[TYPES_ENUM['paper']].card_sprite):
                    return make_choice(option_cards[TYPES_ENUM['paper']])

                elif pygame_functions.spriteClicked(option_cards[TYPES_ENUM['scissors']].card_sprite):
                    return make_choice(option_cards[TYPES_ENUM['scissors']])


def make_choice(chosen_card):
    """
    Show the chosen card and return its details details.
    :param chosen_card: The card object that was chosen. (Card)
    :return: The stats of the card
    """

    pygame_functions.hideAll()
    pygame_functions.animate_sprite_movement(SCREEN_SIZE_X // 2, SCREEN_SIZE_Y // 2, chosen_card.card_sprite, 0.015)
    pygame_functions.showSprite(chosen_card.card_sprite)

    return chosen_card.card_type, chosen_card.card_factor


def detect_luck_investment(luck_meter):
    """Determine how much luck the player wants to invest in the die roll.
    Currently a placeholder that waits for the player to click on the luck meter."""
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            elif pygame_functions.keyPressed('esc'):
                pygame.quit()
            else:
    #while not pygame_functions.keyPressed('esc'):
                if pygame_functions.spriteClicked(luck_meter):
                    return 0


# TODO : this seems to be unnecessary because the player class has
# a function that does the same thing
# def calculate_dice_by_luck(luck_factor):
#     """
#     Calculate the result of the dice, according to the players luck factor.
#     :param luck_factor: The player's luck factor (between 1 - 6). (int)
#     :return: The result of the dice throw. (int)
#     """
#     return random.choice(range(luck_factor, 7))



def throw_dice(luck_factor, player):
    """
    Display the dice throwing animation and return the result.
    :return: The result of the dice roll. (int)
    """
    # TODO: cannot quit game while rolling dice.
    
    DICE_IMAGE_SIZE = 128

    dice_path = 'assets\\pictures\\dice\\dice_'
    dice_sprite = pygame_functions.newSprite(dice_path + '1.png')
    pygame_functions.moveSprite(dice_sprite, SCREEN_SIZE_X // 2, SCREEN_SIZE_Y // 2)

    # Animation of the dice roll.

    for runs in range(3):
        for index in range(1, 7):
            pygame_functions.setSpriteImage(dice_sprite, pygame_functions.loadImage(dice_path+str(index)+'.png'))
            pygame_functions.showSprite(dice_sprite)
            sleep(0.05)

    # Actually generate the cards luck.
    luck_choice = player.dice_throw(luck=luck_factor)

    pygame_functions.setSpriteImage(dice_sprite, pygame_functions.loadImage(dice_path+str(luck_choice)+'.png'))
    pygame_functions.showSprite(dice_sprite)

    sleep(1.5)

    # Move the dice to the side.
    pygame_functions.animate_sprite_movement(SCREEN_SIZE_X - (DICE_IMAGE_SIZE // 2), SCREEN_SIZE_Y // 2, dice_sprite, 0.01)

    return luck_choice


def choose_winner(card1, card2):
    """"
    Choose which of the two players (1-player, 2-computer) wins the current round
    Arguments: two tuples containing card type and card factor
    Returns: 'player' or 'computer', the winning player (str)
    """
    factor1 = card1[1]
    factor2 = card2[1]
    type1 = card1[0]
    type2 = card2[0]

    if type1 == type2:
        if factor1 == factor2:
            # we'll add something later to deal with complete
            # stalemates. or maybe returning 0 is what will happen
            return 'tie'
        if factor1 > factor2:
            return 'player'
        return 'computer'

    if factor1 == players.DICE_SIZE:
        if factor2 != players.DICE_SIZE:
            return 'player'
        # if both are equal max dice size, pass and decide
        # in the usual way
        pass
    elif factor2 == players.DICE_SIZE :
        return 'computer'

    if type1 == 'paper':
        if type2 == 'rock':
            return 'player'
        return 'computer'
    elif type1 == 'scissors':
        if type2 == 'paper':
            return 'player'
        return 'computer'
    elif type1 == 'rock':
        if type2 == 'scissors':
            return 'player'
        return 'computer'
    else:
        print("A terrible mistake in choose_winner!")
        pygame.quit()



class Slider():
    def __init__(self, name, val, maxi, mini, xpos, ypos):
        self.val = val  # start value
        self.maxi = maxi  # maximum at slider position right
        self.mini = mini  # minimum at slider position left
        self.xpos = xpos  # x-location on screen
        self.ypos = ypos
        self.surf = pygame.surface.Surface((100, 50))
        self.hit = False
        # draw the slider itself
        self.surf.fill((100, 100, 100))
        pygame.draw.rect(self.surf, GREY, [0, 0, 100, 50], 3)
        pygame.draw.rect(self.surf, ORANGE, [10, 10, 80, 10], 0)
        pygame.draw.rect(self.surf, WHITE, [10, 30, 80, 5], 0)
        #self.surf.blit(self.txt_surf, self.txt_rect)
        # draw the button that will move around the slider
        self.button_surf = pygame.surface.Surface((20, 20))
        self.button_surf.fill(TRANS)
        self.button_surf.set_colorkey(TRANS)
        pygame.draw.circle(self.button_surf, BLACK, (10, 10), 6, 0)
        pygame.draw.circle(self.button_surf, ORANGE, (10, 10), 4, 0)
        


def turn(player, enemy_player):
    """
    Runs a turn of the game of a human against the computer
    :param player: the human player (class HumanPlayer)
    :param enemy_player: the computer player (class ComputerPlayer)
    """
    # TODO: I think that this doesn't need to be in another while not esc loop, but I'm not sure
    player_luck = player.get_luck()
    # TODO: currently this is unused, but maybe the computer will need it for decision making if the ai
    # becomes more advanced, and then it will be another argument to computer.take_action
    computer_luck = enemy_player.get_luck()
    cards = init_cards()
    win_sprite = pygame_functions.newSprite('assets\\pictures\\luck\\win.png')
    lose_sprite = pygame_functions.newSprite('assets\\pictures\\luck\\lose.png') 
    tie_sprite = pygame_functions.newSprite('assets\\pictures\\luck\\tie.png')
    
    sprite_x = SCREEN_SIZE_X // 2
    sprite_y = SCREEN_SIZE_Y // 2  
    
    
    luck_meter = show_luck_meter(player)
    # TODO: this of course recieves max player current luck instead of 100
    luck_to_invest = detect_luck_investment(luck_meter)
    player_dice_throw = throw_dice(luck_to_invest, player)
    # maybe in the future have computer.take_action return the amount of luck to invest and then the action
    # to take. Meanwhile the computer always invests 0 points.
    computer_dice_throw = enemy_player.dice_throw(0)

    card_sprites = show_cards(player_dice_throw, cards)
    player_move = detect_choice(card_sprites)
    # again, change this when the ai becomes smarter
    computer_move = enemy_player.take_action(player, computer_dice_throw)
    
    # TODO: add point scoring system and battle animation (or at least a way to see what the computer did)
    winner = choose_winner(player_move, computer_move)
    
    pygame_functions.hideAll()
    
    if winner == 'player':
        pygame_functions.moveSprite(win_sprite, sprite_x, sprite_y)
        pygame_functions.showSprite(win_sprite)
    elif winner == 'computer':
        pygame_functions.moveSprite(lose_sprite, sprite_x, sprite_y)
        pygame_functions.showSprite(lose_sprite)
    elif winner == 'tie':
        # TODO: implement a tiebreaker
        pygame_functions.moveSprite(tie_sprite, sprite_x, sprite_y)
        pygame_functions.showSprite(tie_sprite)
    else:
        print("There's been a terrible mistake in turn!")
        pygame.quit()
        
    # increment luck by growth factor (currently 1)
    if player_luck <= (MAX_LUCK - LUCK_GROWTH_FACTOR):
        player.set_luck(player_luck + LUCK_GROWTH_FACTOR)
        print(player.get_luck())
        
    time_slept = 0
    while time_slept < RESULT_DISPLAY_TIME:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            elif pygame_functions.keyPressed('esc'):
                pygame.quit()
            else:
                sleep(0.05)
                time_slept += 0.05
                
    pygame_functions.hideAll()
    
    
def main():

    pygame_functions.screenSize(SCREEN_SIZE_X, SCREEN_SIZE_Y, fullscreen=False)
    luck_factor = 4
    cards = init_cards()

    player = players.HumanPlayer()
    computer = players.ComputerPlayer()
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            else:
                pygame_functions.setBackgroundColour('black')
                turn(player, computer)
    
    #while not pygame_functions.keyPressed('esc'):
        # TODO: make a game table background.
        # pygame_functions.setBackgroundColour('black')
        # turn(player, computer)

        # current_luck = throw_dice(luck_factor)

        # card_sprites = show_cards(current_luck, cards)
        # print(detect_choice(card_sprites))
        # sleep(1)
        # pygame_functions.hideAll()

    #pygame_functions.endWait()


if __name__ == '__main__':
    main()