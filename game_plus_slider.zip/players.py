import pygame_functions
import random

MAX_LUCK = 100
DICE_SIZE = 6

class Player:
    def __init__(self):
        self.__luck = MAX_LUCK // 2
        self.__dice_size = DICE_SIZE
        self.actions = ["Paper", "Scissors", "Rock"]

    def dice_throw(self, luck):
        """returns an integer containing the result of the dice throw"""
        choices_array = []
        weights = []
        for index in range(self.__dice_size):
            choices_array.append(index + 1)
            weights.append(1)

        if luck != 0:
            for index in range(self.__dice_size):
                weights[index] += (luck / 100) * (index + 1)
        
        result = str(random.choices(choices_array, weights=weights))
        result = result.replace('[', '')
        result = result.replace(']', '')
        
        return int(result)

    def get_luck(self):
        return self.__luck

    def set_luck(self, new_luck):
        self.__luck = new_luck


class HumanPlayer(Player):
    def __init__(self):
        Player.__init__(self)


class ComputerPlayer(Player):
    def __init__(self):
        Player.__init__(self)

    def take_action(self, enemy_player, dice_result):
        """What will the computer's strategy be?"""
        return 'rock', dice_result


# Suggestion: maybe add take_turn to the human player class, since the computer player has the 
# equivalent 'take action'
def take_turn(player):
    temp = Metal.init_screen_function(player.get_luck_max_six())
    return temp
    
    
def choose_winner(card1, card2):
    """"
    Choose which of the two players wins the current round
    Arguments: two tuples containing card type and card factor
    Returns: 1 or 2, the number of the winning player
    """
    factor1 = card1[1]
    factor2 = card2[1]
    type1 = card1[0]
    type2 = card2[0]

    if type1 == type2:
        if factor1 == factor2:
            # we'll add something later to deal with complete
            # stalemates. or maybe returning 0 is what will happen
            return 0
        if factor1 > factor2:
            return 1
        return 2

    if factor1 == DICE_SIZE:
        if factor2 != DICE_SIZE:
            return 1
        # if both are equal max dice size, pass and decide
        # in the usual way
        pass
    elif factor2 == DICE_SIZE :
        return 2

    if type1 == 'paper':
        if type2 == 'rock':
            return 1
        return 2
    elif type1 == 'scissors':
        if type2 == 'paper':
            return 1
        return 2
    elif type1 == 'rock':
        if type2 == 'scissors':
            return 1
        return 2
        

